<template>
<div class="max-w-7xl mx-auto">

</div>

</template>

<script setup>
import Navbar from "./components/Navbar.vue";


</script>




<style scoped>


</style>